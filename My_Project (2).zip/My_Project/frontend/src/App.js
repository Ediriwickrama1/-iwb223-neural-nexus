import React, { Suspense } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Route, Routes, BrowserRouter } from 'react-router-dom';
import Home from './PAGES/HomePage/Home';
import './App.css';

// Import Slick Carousel CSS
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

import About from './PAGES/Extra/About';
import Contact from './PAGES/Extra/Contact';

import AccessLevel from './PAGES/Extra/AccessLevel';
import AccessLevelForSignIn from './PAGES/Extra/AccessLevelForSignUp';

import OfficerLogin from "./PAGES/AuthOfficer/OfficerLogin";
import Officersignup from "./PAGES/AuthOfficer/OfficerSignup";
import OfficerForgotPassword from "./PAGES/AuthOfficer/OfficerForgotPassword";

import LoginUser from "./PAGES/Auth/Login";
import Login from './PAGES/Auth/Login';

import SignUpUser from './PAGES/Auth/Signup';
import OfficerSignUp from './PAGES/AuthOfficer/OfficerSignup';

import ForgotPassword from './PAGES/Auth/ForgotPassword';

import UserProfile from './PAGES/User/UserProfile';
import OfficerProfile from './PAGES/Officer/UserProfile';

import FAQ from './PAGES/Extra/FAQ';
import Termsandconditions from './PAGES/Extra/Termsandconditions';
import PrivacyPolicy from './PAGES/Extra/PrivacyPolicy';

import ApplicationForm from './PAGES/Application/ApplicationForm';
import ApplicationForm2 from './PAGES/Application/ApplicationForm2';
import ApplicationForm3 from './PAGES/Application/ApplicationForm3';
import DocumentUploadPage from './PAGES/Application/DocumentUploadPage';
import DonationForm from './COMPONENTS/Donation/DonationForm';

import './118n.js';
import DonateEvidence from './COMPONENTS/Donation/DonateEvidence';

function Loading() {
  return (
    <div className='load'>
      <>Loading...</>
    </div>
  );
}

const App = () => {
  return (
    <Suspense fallback={<Loading />}>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/home" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/login" element={<Login />} />
          <Route path="/AccessLevel" element={<AccessLevel />} />
          <Route path="/LoginUser" element={<LoginUser />} />
          <Route path="/OfficerLogin" element={<OfficerLogin />} />
          <Route path="/Officersignup" element={<Officersignup />} />
          <Route path="/OfficerForgotPassword" element={<OfficerForgotPassword />} />

          <Route path="/AccessLevelForSignUp" element={<AccessLevelForSignIn />} />
          <Route path="/SignUpUser" element={<SignUpUser />} />
          <Route path="/OfficerSignUp" element={<OfficerSignUp />} />

          <Route path="/forgotpassword" element={<ForgotPassword />} />

          <Route path="/UserProfile/:activepage" element={<UserProfile />} />
          <Route path="/OfficerProfile/:activepage" element={<OfficerProfile />} />

          <Route path="/FAQ" element={<FAQ />} />
          <Route path="/termsandconditions" element={<Termsandconditions />} />
          <Route path="/privacypolicy" element={<PrivacyPolicy />} />

          <Route path="/ApplicationForm" element={<ApplicationForm />} />
          <Route path="/ApplicationForm2" element={<ApplicationForm2 />} />
          <Route path="/ApplicationForm3" element={<ApplicationForm3 />} />
          <Route path="/DocumentUploadPage" element={<DocumentUploadPage />} />
          <Route path="/DonationForm" element={<DonationForm />} />
          <Route path="/DonateEvidence" element={<DonateEvidence />} />
        </Routes>
      </BrowserRouter>
    </Suspense>
  );
}

export default App;
